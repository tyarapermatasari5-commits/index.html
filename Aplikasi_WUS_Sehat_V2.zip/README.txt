APLIKASI WUS SEHAT
===================

Isi:
- index.html : website utama, sudah berisi HTML + CSS + JavaScript dalam satu file.
- README.txt : panduan edit dan publikasi.

FITUR:
1. Kalender haid: klik tanggal untuk menandai/menghapus haid. Data tersimpan di browser (localStorage).
2. Kalkulator siklus haid: tanggal haid terakhir + panjang siklus.
3. Kalkulator IMT.
4. Artikel nutrisi/kesuburan dengan tautan sumber Hello Sehat.
5. Artikel 7 ciri wanita subur dengan tautan sumber Alodokter.
6. Animasi edukasi ovulasi bawaan, tanpa aplikasi tambahan.

CARA EDIT:
- Buka index.html dengan VS Code, Notepad++, atau editor kode lain.
- Cari teks yang ingin diubah lalu simpan.
- Untuk mengganti video animasi dengan YouTube, bagian <section id="video"> dapat diganti dengan iframe YouTube.
- Warna utama dapat diubah di bagian :root pada CSS.

CARA MEMBUAT ONLINE GRATIS:
Pilihan paling mudah adalah GitHub Pages:
1. Buat akun GitHub.
2. Buat repository baru, misalnya "wus-sehat".
3. Upload index.html.
4. Buka Settings > Pages.
5. Pilih Deploy from branch, branch main, folder /root.
6. Simpan. GitHub akan memberikan link website publik.

Alternatif: Netlify atau Vercel juga dapat digunakan untuk hosting file statis.

CATATAN:
Kalkulator siklus hanya memberikan perkiraan berdasarkan data yang dimasukkan. Hasil bukan diagnosis dan tidak menjamin waktu ovulasi.
